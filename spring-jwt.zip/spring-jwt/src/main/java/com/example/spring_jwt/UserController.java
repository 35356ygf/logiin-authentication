package com.example.spring_jwt;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession; // Import HttpSession
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class UserController {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private JWTUtil jwtUtil;

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/login")
    public String loginUser(User user, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        User existingUser = userRepository.findByEmail(user.getEmail());
        if (existingUser != null && user.getPassword().equals(existingUser.getPassword())) {
            String token = jwtUtil.generateToken(existingUser.getEmail());
            HttpSession session = request.getSession();
            session.setAttribute("token", token); // Store the token in the session
            if (existingUser.getType().equals("user")) {
                return "redirect:/user-detail"; // Redirect without token in URL
            } else if (existingUser.getType().equals("admin")) {
                return "redirect:/admin-detail"; // Redirect without token in URL
            }
        }
        return "redirect:/login?error";
    }

    @GetMapping("/user-detail")
    public String userDetail(Model model, HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            String token = (String) session.getAttribute("token"); // Retrieve the token from session
            if (token != null && jwtUtil.validateToken(token)) {
                return "user-detail"; // Show user details
            }
        }
        return "redirect:/login"; // Redirect to login if token is not valid
    }

    @GetMapping("/admin-detail")
    public String adminDetail(Model model, HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            String token = (String) session.getAttribute("token"); // Retrieve the token from session
            if (token != null && jwtUtil.validateToken(token)) {
                return "admin-detail"; // Show admin details
            }
        }
        return "redirect:/login"; // Redirect to login if token is not valid
    }

    // Logout endpoint
    @GetMapping("/logout")
    public String logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate(); // Invalidate the session
        }
        return "redirect:/login"; // Redirect to login page
    }
}
